package mcbbs.crafttime.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

import org.bukkit.scheduler.BukkitRunnable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.configuration.Config;
import mcbbs.crafttime.configuration.Rules;
import mcbbs.crafttime.exception.FolderNotFound;
import mcbbs.crafttime.exception.NotIsFolder;
import mcbbs.crafttime.my.ConfigEntry;
import mcbbs.crafttime.tools.Logger;
import mcbbs.crafttime.tools.StringToFile;
import mcbbs.crafttime.util.Json;

public class BukkitServer extends BukkitRunnable
{
	private ServerSocket ss = null;
	private Config config = null;
	private Rules rules = null;
	private boolean s = true;
	
	private final String UTOF = "开启更新线程在 /Port/ 上失败！";
	private final String UTOS = "开启更新线程在 /Port/ 上成功！";
	private final String CSM = "来自 /HostAddress/ 的用户连接了服务端";
	private final String UTO = "更新线程已关闭";
	private final String CCL = "与 /HostAddress/ 的连接丢失";

	
	
	public BukkitServer (Config config, Rules rules)
	{
		this.config = config;
		this.rules = rules;
	}
	
	public void run() 
	{
		//开启端口监听
		listening(this.config.getPort());
		
		//开始工作
		try 
		{
			startwork();
		} 
		catch (NotIsFolder e) 
		{
			e.printStackTrace();
		} 
		catch (FolderNotFound e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public void close()
	{
		if(s)
		{
			this.s = false;
			try 
			{
				Socket s = new Socket("127.0.0.1", this.config.getPort());
				s.close();
			} 
			catch (IOException e) {}
			
		}
	}
	
	
	private void startwork() throws NotIsFolder, FolderNotFound
	{
		System.out.println("开启在"+config.getPort());
		
		Socket s = null;
		
		while(true)
		{
			try 
			{
				//接受请求
				s = ss.accept();
				
				//如果是关闭线程
				if(!this.s){break;}
				
				//进行处理
				this.handler(s);
				
				//关闭套接字
				s.close();
			}
			catch (IOException e) {e.printStackTrace();}
			
		}
		
		try 
		{
			//关闭服务器更新线程
			this.ss.close();
			//关闭
			Logger.info(this.UTO);
		} 
		catch (IOException e){e.printStackTrace();}
	}
	
	
	private void listening(int port)
	{
		
		//监听端口
		try 
		{
			this.ss = new ServerSocket(port);
		} 
		catch (IOException e) 
		{
			//开启失败
			e.printStackTrace();
			Logger.warning(this.UTOF.replaceAll("/Port/", this.config.getPort()+""));
			return;
		}
		
		//开启成功
		Logger.info(this.UTOS.replaceAll("/Port/", this.config.getPort()+""));
	}
	
	private void handler(Socket s) throws NotIsFolder, FolderNotFound
	{
		DataInputStream netIn = null;
		DataOutputStream netOut = null;
		
		try
		{
			
			netIn = new DataInputStream(s.getInputStream());
			netOut = new DataOutputStream(s.getOutputStream());
			
			//获取客户端行为(0获取列表/1下载文件)
			int act = netIn.readInt();
			
			switch (act)
			{
				//获取服务端文件信息
				case 0:
				{
					try 
					{
						this.getInfo(netIn, netOut);
					} 
					catch (JSONException e) {e.printStackTrace();}
					
					//记录
					Logger.info(this.CSM.replaceAll("/HostAddress/", s.getInetAddress().getHostAddress()));
					return;
				}
				
				case 1:
				{
					
					this.downloadFile(netIn, netOut);
					
					return;
				}
					
			}
			
		}
		catch (IOException e) 
		{
			//连接丢失
			Logger.error(this.CCL.replaceAll("/HostAddress/", s.getInetAddress().getHostAddress()));
		}
		finally
		{
			try 
			{
				netIn.close();
				netOut.close();
			} 
			catch (IOException e) {e.printStackTrace();}
		}
		
	}
	
	private void getInfo(DataInputStream netIn, DataOutputStream netOut) throws JSONException, NotIsFolder, FolderNotFound
	{
		
		JSONArray all = new JSONArray();
		
		HashMap<String, ConfigEntry> entrys = this.rules.getEntry();
		
		for(ConfigEntry temp : entrys.values())
		{
			JSONObject json = new JSONObject();
			json.put("nick", temp.getNick());
			json.put("path", temp.getRemotePath());
			json.put("stru", new Json(temp.getLocalPath()).getJson());
			
			all.put(json);
		}
		
		try 
		{
			netOut.writeUTF(all.toString());
		} 
		catch (IOException e) {e.printStackTrace();}
		
	}
	
	private void downloadFile(DataInputStream netIn, DataOutputStream netOut) throws IOException
	{
		//接受文件路径
		String resstr = netIn.readUTF();
		
		System.out.println("请求:"+resstr);
		
		String nick = resstr.split("######")[0];
		
		String path = resstr.split("######")[1];
		
		StringToFile stf = new StringToFile(rules, nick, path);
		
		File downloadfile = stf.getFile();
		
		Upload uload = new Upload(netOut, downloadfile, this.config.getDelay());
		
		uload.ul();
		
	}
	
}
