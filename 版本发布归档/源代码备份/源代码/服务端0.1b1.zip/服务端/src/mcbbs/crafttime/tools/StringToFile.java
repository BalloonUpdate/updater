package mcbbs.crafttime.tools;

import java.io.File;
import java.util.HashMap;

import mcbbs.crafttime.configuration.Rules;
import mcbbs.crafttime.my.ConfigEntry;

public class StringToFile 
{
	private Rules rules = null;
	private String nick = null;
	private String path =null;
	
	
	public StringToFile(Rules rules, String nick, String path)
	{
		this.rules = rules;
		this.nick = nick;
		this.path = path;
	}
	
	public File getFile()
	{
		HashMap<String, ConfigEntry> entrys = this.rules.getEntry();
		ConfigEntry dik = entrys.get(nick);

		String[] pathsp = path.split("####");
		
		File beg = dik.getLocalPath();
		
		for(String tmp : pathsp)
		{
			beg = to(beg, tmp);
		}
		
		return beg;
		
	}
	
	private File to (File folder, String file)
	{
		return new File(folder, file);
	}
}
