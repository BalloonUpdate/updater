package mcbbs.crafttime.net;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Upload 
{
	private DataOutputStream netOut =  null;
	private File file = null;
	private long delay = 0;
	
	public Upload(DataOutputStream netOut, File file, long delay)
	{
		this.netOut = netOut;
		this.file = file;
		this.delay = delay;
	}
	
	public void ul() throws IOException
	{
			
		FileInputStream fileIn = new FileInputStream(file);
		
		netOut.writeLong(file.length());
		
		byte[] buffer = new byte[1024*8];
		int len = 0;
		
		while((len = fileIn.read(buffer))!=-1)
		{
				netOut.write(buffer, 0, len);
				try 
				{
					Thread.sleep(delay);
				} catch (InterruptedException e) {e.printStackTrace();}
		}
		
		fileIn.close();
		
	}
	
}
