package mcbbs.crafttime.exception;

public class Empty extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4272047053725286427L;

	public Empty(String path)
	{
		super("["+path+"] 为空");
	}
}
