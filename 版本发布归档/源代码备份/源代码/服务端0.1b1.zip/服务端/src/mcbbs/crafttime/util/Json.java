package mcbbs.crafttime.util;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.exception.FolderNotFound;
import mcbbs.crafttime.exception.NotIsFolder;
import mcbbs.crafttime.tools.MD5;

public class Json 
{
	private File Folder = null;
	
	public Json(File Folder) throws NotIsFolder, FolderNotFound
	{
		if(!Folder.exists())
		{
			throw new FolderNotFound(Folder.getName());
		}
		if(Folder.isFile())
		{
			throw new NotIsFolder(Folder.getName());
		}
		
		this.Folder = Folder;
	}
	
	public String getJsonString()
	{
		JSONObject ru = null;
		try 
		{
			ru = this.Folder(this.Folder);
		} 
		catch (NoSuchAlgorithmException | JSONException | IOException e) {e.printStackTrace();}
		return ru.toString();
	}
	

	private JSONObject Folder(File Folder) throws JSONException, NoSuchAlgorithmException, IOException 
	{
		JSONObject job = new JSONObject();
		
		File[] list = Folder.listFiles();
		
		for(File f : list)
		{
			if(f.isFile())
			{
				job.put(f.getName(), MD5.getMD5(f).toUpperCase());
				continue;
			}
			
			if(f.isDirectory())
			{
				JSONObject tc = this.Folder(f);
				job.put(f.getName(), tc);
			}
		}
		
		return job;
	}
	
	public JSONObject getJson()
	{
		JSONObject ru = null;
		try 
		{
			ru = this.Folder(this.Folder);
		} 
		catch (NoSuchAlgorithmException | JSONException | IOException e) {e.printStackTrace();}
		return ru;
	}
	
}
