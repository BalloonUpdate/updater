package mcbbs.crafttime.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger
{
	private static boolean Enable = false;
	private static File log = null;
	
	//构造方法
	public Logger (boolean Enable, File log)
	{
		Logger.Enable = Enable;
		
		if(!log.exists())
		{
			try 
			{
				log.createNewFile();
			} 
			catch (IOException e) {e.printStackTrace();}
		}
		
		Logger.log = log;
	}
	
	//info方法
	public static boolean info(String msg)
	{
		if(!Logger.Enable)
		{
			return false;
		}
		
		String prefix = "["+(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()))+"][信息]";
		
		try 
		{
			if(!log.exists())
			{
				log.createNewFile();
			}
			BufferedWriter w = new BufferedWriter(new FileWriter (log, true));
			
			w.write(prefix+" "+msg);
			w.newLine();
			w.close();
		} 
		catch (IOException e) {e.printStackTrace();}
		
		return true;
	}
	
	//warning方法
	public static boolean warning(String msg)
	{
		if(!Logger.Enable)
		{
			return false;
		}
		
		String prefix = "["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+"][警告]";
		
		try 
		{
			BufferedWriter w = new BufferedWriter(new FileWriter (log, true));
			w.write(prefix+" "+msg);
			w.newLine();
			w.close();
		} 
		catch (IOException e) {e.printStackTrace();}
		
		return true;
	}
	
	//error方法
	public static boolean error(String msg)
	{
		if(!Logger.Enable)
		{
			return false;
		}
		
		String prefix = "["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+"][错误]";
		
		try 
		{
			BufferedWriter w = new BufferedWriter(new FileWriter (log, true));
			w.write(prefix+" "+msg);
			w.newLine();
			w.close();
		} 
		catch (IOException e) {e.printStackTrace();}
		
		return true;
	}
	
}
