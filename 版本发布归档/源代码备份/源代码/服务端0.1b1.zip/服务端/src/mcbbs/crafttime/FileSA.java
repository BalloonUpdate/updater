package mcbbs.crafttime;

import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

import mcbbs.crafttime.configuration.Config;
import mcbbs.crafttime.configuration.Rules;
import mcbbs.crafttime.exception.Empty;
import mcbbs.crafttime.exception.FolderNotFound;
import mcbbs.crafttime.exception.NotIsFolder;
import mcbbs.crafttime.exception.PortConflicts;
import mcbbs.crafttime.my.ConfigEntry;
import mcbbs.crafttime.net.BukkitServer;
import mcbbs.crafttime.tools.Logger;

public class FileSA extends JavaPlugin
{
	private BukkitServer  AServer = null;
	private Config config = null;
	private Rules rules = null;
	
	public void onEnable()
	{
		File datafolder = this.getDataFolder();
		File configfile = new File(datafolder, "config.yml");
		File rulesfile = new File(datafolder, "rules.txt");
		int mcport = this.getServer().getPort();
		
		
		
		//初始化配置文件夹
		this.pluginfolder(datafolder, configfile);
		
		//初始化两个配置文件
		try 
		{
			try 
			{
				
				this.configuration(configfile, mcport, rulesfile);
				
				//运行更新线程
				start();
			}
			catch (FolderNotFound e) 
			{
				this.getServer().getPluginManager().disablePlugin(this);
				e.printStackTrace();
			}
			catch (NotIsFolder e) 
			{
				this.getServer().getPluginManager().disablePlugin(this);
				e.printStackTrace();
			}
			
			new Logger (true, new File(this.getDataFolder(), "1.log"));
			
			
			

			
			
		} 
		catch (PortConflicts e) 
		{
			this.getServer().getPluginManager().disablePlugin(this);
			e.printStackTrace();
		} 
		catch (Empty e) 
		{
			this.getServer().getPluginManager().disablePlugin(this);
			e.printStackTrace();
		}
		
		
		

		
	}
	
	//关闭线程
	public void onDisable()
	{
		if(AServer!=null)
		{
			AServer.cancel();
			AServer.close();
		}
	}
	
	private void pluginfolder(File datafolder, File configfile)
	{
		//插件文件夹不存在就创建
		if(!datafolder.exists())
		{
			datafolder.mkdirs();
		}
		
		//config.yml不存在就创建
		if(!configfile.exists())
		{
			this.saveDefaultConfig();
		}
		
	}
	
	private void configuration(File configfile, int mcport, File rulesfile) throws PortConflicts, Empty, FolderNotFound, NotIsFolder
	{
		this.config = new Config(configfile, mcport);
		
		this.rules = new Rules(rulesfile);
		
		
		//验证配置文件
		
		for(ConfigEntry t : rules.getEntry().values())
		{
			if(!t.getLocalPath().exists())
			{
				throw new FolderNotFound(t.getLocalPath().getName());
			}
			else
			{
				if(t.getLocalPath().isFile())
				{
					throw new NotIsFolder(t.getLocalPath().getName());
				}
			}
			
		}
	}
	
	
 	private void start()
	{
		this.AServer = new BukkitServer(config, rules);
		this.AServer.runTaskAsynchronously(this);
	}
	
}
