package mcbbs.crafttime.configuration;

import java.io.File;
import java.io.IOException;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import mcbbs.crafttime.exception.PortConflicts;


public class Config 
{
	//运行端口
	private int Port = 0;
	
	//传输延迟
	private long Delay = 0;
	
	//配置文件Key
	private final String PortKey = "Port";
	private final String MaxSpeedKey = "MaxSpeed";
	
	//构造方法
	public Config (File config, int MCport) throws PortConflicts
	{
		
		YamlConfiguration cfg = new YamlConfiguration();
		
		try 
		{
			cfg.load(config);
		} 
		catch (InvalidConfigurationException | IOException e) {e.printStackTrace();}
		
		
		//获取端口
		int Port = cfg.getInt(this.PortKey);
		
		//获取最大速度
		long MaxSpeed = cfg.getLong(this.MaxSpeedKey);
		
		
		init(MCport, MaxSpeed);
		
		
		this.Port = Port;
	}
	
	private void init(int MCport, long MaxSpeed) throws PortConflicts
	{
		//端口检查
		if(Port==MCport)
		{
			throw new PortConflicts();
		}
		
		//最大速度检查
		long Delay = 0;
		if(MaxSpeed<=0)
		{
			Delay = 0;
		}
		else
		{
			Delay = 1000/(MaxSpeed/8);
		}
		
		this.Delay = Delay;
		
	}
	
	public int getPort()
	{
		return this.Port;
	}
	
	public long getDelay()
	{
		return this.Delay;
	}
	
}
