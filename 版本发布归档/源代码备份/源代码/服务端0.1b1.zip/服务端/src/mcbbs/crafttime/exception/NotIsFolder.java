package mcbbs.crafttime.exception;

public class NotIsFolder extends Exception 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5856206622927992510L;

	public NotIsFolder(String path)
	{
		super("["+path+"] 是一个文件，而非文件夹！");
	}
}
