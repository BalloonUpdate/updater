package mcbbs.crafttime.exception;

public class FileEmpty extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2032816451035204601L;
	
	public FileEmpty(String path)
	{
		super("文件 ["+path+"] 为空");
	}
}
