package mcbbs.crafttime.exception;

public class FolderNotFound extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2057416030887853968L;

	public FolderNotFound(String path)
	{
		super("文件夹 ["+path+"] 不存在");
	}
}
