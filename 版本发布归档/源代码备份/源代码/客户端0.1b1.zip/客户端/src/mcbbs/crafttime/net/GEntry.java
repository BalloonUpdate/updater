package mcbbs.crafttime.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.exception.CannotConnecting;
import mcbbs.crafttime.my.WorkEntry;

public class GEntry 
{
	private Address address = null;
	
	public GEntry(Address address)
	{
		this.address = address;
	}
	
	public ArrayList<WorkEntry> getWorkEntrys() throws CannotConnecting
	{
		Socket s = null;
		try 
		{
			s = new Socket(address.getIPaddress(), address.getPort());
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			throw new CannotConnecting(address);
		}
		
		DataInputStream netIn = null;
		DataOutputStream netOut = null;
		ArrayList<WorkEntry> wentry = new ArrayList<>();
		
		try 
		{
			netIn = new DataInputStream(s.getInputStream());
			netOut = new DataOutputStream(s.getOutputStream());
			
			netOut.writeInt(0);
			
			String resstr = netIn.readUTF();
			
			s.close();
			
			JSONArray entryarray = new JSONArray(resstr);
			
			int lenth = entryarray.length();
			
			ArrayList<JSONObject> entrys = new ArrayList<>();
			
			for(int c = 0;c<lenth;c++)
			{
				entrys.add(entryarray.getJSONObject(c));
			}
			
			
			for(JSONObject temp : entrys)
			{
				System.out.println(temp);
				wentry.add(new WorkEntry(address, temp.getString("nick"), new File(temp.getString("path")), temp.getJSONObject("stru")));
			}
			
		} 
		catch (IOException | JSONException e) {e.printStackTrace();}
		
		return wentry;
	}
}
