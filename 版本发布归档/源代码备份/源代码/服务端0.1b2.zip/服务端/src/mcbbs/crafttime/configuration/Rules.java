package mcbbs.crafttime.configuration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import mcbbs.crafttime.exception.Empty;
import mcbbs.crafttime.tools.RuleEntrys;

public class Rules 
{
	File file = null;
	HashMap<String, RuleEntrys> entrylist = null;
	
	public Rules(File file) throws Empty
	{
		this.file = file;
		try 
		{
			init();
		} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	private void init() throws IOException, Empty
	{
		if(!file.exists())
		{
			file.createNewFile();
		}
		
		BufferedReader entryfile = new BufferedReader(new FileReader(file));
		String temp = "";
		entrylist = new HashMap<>();
		while((temp=entryfile.readLine())!=null)
		{
			if(temp.split("#").length==3)
			{
				String[] res = temp.split("#");
				entrylist.put(res[0], new RuleEntrys(res[0], res[1], new File(res[2])));
			}
		}
		entryfile.close();
		
		if(entrylist.isEmpty())
		{
			throw new Empty("rules.txt文件");
		}
	}
	
	public HashMap<String, RuleEntrys> getEntry()
	{
		return entrylist;
	}
}
