package mcbbs.crafttime;

import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

import mcbbs.crafttime.configuration.Config;
import mcbbs.crafttime.configuration.Rules;
import mcbbs.crafttime.exception.Empty;
import mcbbs.crafttime.exception.FolderNotFound;
import mcbbs.crafttime.exception.NotIsFolder;
import mcbbs.crafttime.exception.PortConflicts;
import mcbbs.crafttime.net.BukkitServer;
import mcbbs.crafttime.tools.Logger;
import mcbbs.crafttime.tools.RuleEntrys;

public class FileSA extends JavaPlugin
{
	//线程实例
	private BukkitServer  AServer = null;
	
	//config.yml文件
	private Config config = null;
	
	//rules.txt文件
	private Rules rules = null;
	
	//插件启用
	public void onEnable()
	{
		//插件数据文件夹
		File datafolder = this.getDataFolder();
		
		//config.yml文件实例
		File configfile = new File(datafolder, "config.yml");
		
		//rules.txt文件实例
		File rulesfile = new File(datafolder, "rules.txt");
		
		//获取游戏端口
		int mcport = this.getServer().getPort();
		
		//初始化两个配置文件
		try 
		{
			try 
			{
				//初始化配置文件夹
				//创建插件数据文件夹和config.yml (rules.txt由mcbbs.crafttime.configuration.Rules类的构造方法创建)
				pluginfolder(datafolder, configfile);
				
				//加载config.yml和rules.txt
				configuration(configfile, mcport, rulesfile);
				
				//运行更新线程
				start();
			}
			catch (FolderNotFound e) 
			{
				this.getServer().getPluginManager().disablePlugin(this);
				e.printStackTrace();
			}
			catch (NotIsFolder e) 
			{
				this.getServer().getPluginManager().disablePlugin(this);
				e.printStackTrace();
			}
			
			//启用记录器
			new Logger (true, new File(this.getDataFolder(), "1.log"));
		} 
		catch (PortConflicts e) 
		{
			this.getServer().getPluginManager().disablePlugin(this);
			e.printStackTrace();
		} 
		catch (Empty e) 
		{
			this.getServer().getPluginManager().disablePlugin(this);
			e.printStackTrace();
		}
	}
	
	//关闭线程
	//在服务器关闭时关闭更新线程
	public void onDisable()
	{
		if(AServer!=null)
		{
			AServer.close();
		}
	}
	
	//初始化配置文件夹
	private void pluginfolder(File datafolder, File configfile)
	{
		//插件文件夹不存在就创建
		if(!datafolder.exists())
		{
			//创建文件夹
			datafolder.mkdirs();
		}
		
		//config.yml不存在就创建
		if(!configfile.exists())
		{
			//创建配置文件
			this.saveDefaultConfig();
		}
		
	}
	
	//加载config.yml和rules.txt
	private void configuration(File configfile, int mcport, File rulesfile) throws PortConflicts, Empty, FolderNotFound, NotIsFolder
	{
		this.config = new Config(configfile, mcport);
		
		this.rules = new Rules(rulesfile);
		
		
		//验证配置文件
		//检查每一条规则中的文件夹是否不存在或者是一个文件
		for(RuleEntrys t : rules.getEntry().values())
		{
			//如果不存在
			if(!t.getLocalPath().exists())
			{
				throw new FolderNotFound(t.getLocalPath().getName());
			}
			else
			{
				//存在，但是是一个文件
				if(t.getLocalPath().isFile())
				{
					throw new NotIsFolder(t.getLocalPath().getName());
				}
			}
			
		}
	}
	
	//开启线程
 	private void start()
	{
		this.AServer = new BukkitServer(config, rules);
		this.AServer.runTaskAsynchronously(this);
	}
	
}
