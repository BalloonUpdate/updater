package mcbbs.crafttime;

import javax.swing.JOptionPane;

public class Other 
{
	public static void main(String[] args) 
	{
		JOptionPane.showMessageDialog(null, "这是服务端用的插件，不是客户端！", "你搞错了", JOptionPane.DEFAULT_OPTION);
	}
}
