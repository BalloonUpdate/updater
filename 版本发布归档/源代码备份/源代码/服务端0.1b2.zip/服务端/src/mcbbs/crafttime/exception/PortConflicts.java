package mcbbs.crafttime.exception;

public class PortConflicts extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6655758134114405792L;

	public PortConflicts()
	{
		super("更新插件端口和MC端口冲突");
	}

}
