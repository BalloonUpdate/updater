package mcbbs.crafttime.tools;

import java.io.File;

public class RuleEntrys 
{
	String nick;
	String RemotePath;
	File LocalPath;
	
	public RuleEntrys(String nick, String RemotePath,File LocalPath)
	{
		this.nick = nick;
		this.RemotePath = RemotePath;
		this.LocalPath = LocalPath;
	}
	
	public String getNick()
	{
		return nick;
	}
	
	public String getRemotePath()
	{
		return RemotePath;
	}
	
	public File getLocalPath()
	{
		return LocalPath;
	}
}
