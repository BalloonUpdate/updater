package mcbbs.crafttime.tuxingjiemian;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Dwo extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2775161304965015178L;

	public Dwo()
	{
		this.setTitle("...");
		this.setSize(200, 100);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		JLabel tip = new JLabel();
		tip.setText("同步中，请稍等...");
		
		tip.setBounds(10, 10, 100, 50);
		this.add(tip);
		
		
		
	}
}
