package mcbbs.crafttime.tuxingjiemian;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ding extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2775161304965015178L;

	public Ding()
	{
		this.setTitle("...");
		this.setSize(220, 100);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		JLabel tip = new JLabel();
		tip.setText("正在从服务端获取信息，请稍等...");
		
		tip.setBounds(5, 5, 200, 50);
		this.add(tip);
		
		
		
	}
}
