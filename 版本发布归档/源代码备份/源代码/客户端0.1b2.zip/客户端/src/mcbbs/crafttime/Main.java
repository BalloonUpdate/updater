package mcbbs.crafttime;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.json.JSONException;
import mcbbs.crafttime.configuration.Address;
import mcbbs.crafttime.configuration.Cmd;
import mcbbs.crafttime.exception.CannotConnecting;
import mcbbs.crafttime.exception.FileEmpty;
import mcbbs.crafttime.my.WorkEntry;
import mcbbs.crafttime.net.GEntry;
import mcbbs.crafttime.tuxingjiemian.Dwo;
import mcbbs.crafttime.util.WEhander;

public class Main 
{

	public static void main(String[] args) throws IOException 
	{
		Address addconfig = null;
		Cmd cmdconfig = null;
		List<String> adds = null;
		List<String> cmds = null;
		
		try 
		{
			addconfig = new Address();
		} 
		catch (FileEmpty e) 
		{
			JOptionPane.showMessageDialog(null, e.getMessage(), "", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		cmdconfig = new Cmd();
		
		adds = addconfig.getAddresses();
		cmds = cmdconfig.getCmds();
		ArrayList<ArrayList<WorkEntry>> workE = new ArrayList<>();
		
		for(String t0 : adds)
		{
			
			
			
			
			
			
			
			String[] addressport = t0.split(":");
			String address = addressport[0];
			int port = Integer.parseInt(addressport[1]);
			mcbbs.crafttime.net.Address add = new mcbbs.crafttime.net.Address(address, port);
			
			GEntry getes = new GEntry(add);
			
			try 
			{
				workE.add(getes.getWorkEntrys());
			}
			catch (CannotConnecting e) 
			{
				JOptionPane.showMessageDialog(null, e.getMessage(), "", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		for(ArrayList<WorkEntry> t0 : workE)
		{
			System.out.println();
			System.out.println("--------------");
			for(WorkEntry t1 : t0)
			{
				System.out.println();
				System.out.println();
				System.out.println("NICK: "+t1.getNick());
				System.out.println("ADD: "+t1.getAddress().getIPaddress()+" : "+t1.getAddress().getPort());
				System.out.println("FILE: "+t1.getPath().getAbsolutePath());
				System.out.println(t1.getstru());
				System.out.println();
				System.out.println();
			}
			System.out.println("--------------");
			System.out.println();
		}
		
		Dwo g = new Dwo();
		g.setVisible(true);
		
		for(ArrayList<WorkEntry> t0 : workE)
		{
			try 
			{
				new WEhander (t0).h();
			} catch (NoSuchAlgorithmException | JSONException | IOException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			};
		}
		g.dispose();
		
		//JOptionPane.showMessageDialog(null, "完成", "", JOptionPane.PLAIN_MESSAGE);
		
		for(String cmd : cmds)
		{
			Runtime.getRuntime().exec(cmd);
		}
		
	}

}
