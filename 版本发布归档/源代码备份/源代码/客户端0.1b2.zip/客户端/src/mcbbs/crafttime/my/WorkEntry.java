package mcbbs.crafttime.my;

import java.io.File;

import org.json.JSONObject;

import mcbbs.crafttime.net.Address;

public class WorkEntry 
{
	private String nick = null;
	private File path = null;
	private JSONObject stru = null;
	private Address address = null;
	
	public WorkEntry(Address address, String nick, File path, JSONObject stru)
	{
		this.nick = nick;
		this.path = path;
		this.stru = stru;
		this.address = address;
	}
	
	public String getNick()
	{
		return nick;
	}
	
	public File getPath()
	{
		return path;
	}
	
	public JSONObject getstru()
	{
		return stru;
	}
	
	public Address getAddress()
	{
		return address;
	}
	
}
