package mcbbs.crafttime.exception;

import mcbbs.crafttime.net.Address;

public class CannotConnecting extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2032816451035204601L;
	
	private Address address = null;
	
	public CannotConnecting(Address address)
	{
		super("连接 "+address.getIPaddress()+":"+address.getPort()+" 失败！");
		this.address = address;
	}
	
	public Address getAddress()
	{
		return this.address;
	}
}
