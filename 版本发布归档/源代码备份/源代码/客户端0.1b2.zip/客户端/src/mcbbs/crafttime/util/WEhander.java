package mcbbs.crafttime.util;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.my.WorkEntry;
import mcbbs.crafttime.net.Address;
import mcbbs.crafttime.net.Download;

public class WEhander 
{
	private ArrayList<WorkEntry> hentrys = null;
	
	public WEhander(ArrayList<WorkEntry> entrys)
	{
		this.hentrys = entrys;
	}
	
	public void h() throws JSONException, NoSuchAlgorithmException, IOException
	{
		for(WorkEntry t0 : this.hentrys)
		{
			
			
			
			
			Address address = t0.getAddress();
			String nick = t0.getNick();
			File folder = t0.getPath();
			JSONObject stru = t0.getstru();
			
			ArrayList<Download> dofile = new ArrayList<>();
			ArrayList<File> defile = new ArrayList<>();
			
			if(!folder.exists())
			{
				folder.mkdirs();
			}
			
			if(stru.length()!=0)
			{
				down(folder, stru, nick+"##", dofile, defile, address);
				
				dele(folder, stru, defile);
				
				System.out.println("删除X"+defile.size()+" | "+"下载X"+dofile.size());
				
				
				for(Download d : dofile)
				{
					System.out.println(d.getFile().getName());
				}
				
				System.out.println("++++++++++");
				for(File d : defile)
				{
					System.out.println(d.getName());
				}
				
				for(Download dow : dofile)
				{
					dow.dload();
				}
				
				
			}
			else
			{
				File[] list = folder.listFiles();
				for(File t : list)
				{
					del(t);
				}
					
			}
			
			
			
			
			
			
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	private void down(File folder, JSONObject jstr, String mypath, ArrayList<Download> dofile, ArrayList<File> defile, Address address) throws JSONException, NoSuchAlgorithmException, IOException
	{
		//获取所有的键
		ArrayList<String> keys = new ArrayList<>();
		Iterator iter = jstr.keys();
		while(iter.hasNext())
		{
			keys.add((String)iter.next());
		}
		
		//临时变量
		boolean has = false;
		
		for(String t1 : keys)
		{
			System.out.println("xxxxx"+t1);
			
			String[] files = folder.list();
			
			//如果本地文件夹不是空的
			if(files.length!=0)
			{
				
				//把每一个键在本地进行搜索
				for(String t2 : files)
				{
					if(t1.equals(t2))
					{
						//如果搜索到了就记录下来
						has = true;
					}
				}
				
				//建立对应File的实例
				File nfile = new File(folder, t1);
				
				//如果搜得到结果
				if(has)
				{
					
					//远程端是文件
					if(jstr.get(t1) instanceof String)
					{
						//本地是文件
						if(nfile.isFile())
						{
							//验证md5
							String no = MD5.getMD5(nfile).toUpperCase();
							String ol = jstr.getString(t1);
							if(!no.equals(ol))
							{
								//下载
								dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
								
							}
						}
						
						//本地是文件夹
						if(nfile.isDirectory())
						{
							//记录
							defile.add(nfile);
							//删除掉
							del(nfile);
							
							//下载
							dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
						}
					}
					
					//远程端是文件夹
					if(jstr.get(t1) instanceof JSONObject)
					{
						//本地是文件
						if(nfile.isFile())
						{
							//记录
							defile.add(nfile);
							
							//删掉
							del(nfile);
							
							//创建文件夹
							nfile.mkdirs();
							
							//归递处理
							down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address);
						}
						
						//本地是文件夹
						if(nfile.isDirectory())
						{
							//归递处理
							down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address);
						}
						
					}
					
				}
				else//如果没有搜到结果
				{
					//远程端是文件
					if(jstr.get(t1) instanceof String)
					{
						//下载文件
						dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
					}
					
					//远程端是文件夹
					if(jstr.get(t1) instanceof JSONObject)
					{
						//创建文件夹
						nfile.mkdirs();
						
						//归递处理
						down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address);
					}
					
				}
				//清零
				has = false;
			}
			else//如果本地文件夹是空的
			{
				//建立对应File的实例
				File nfile = new File(folder, t1);
				
				//如果是文件
				if(jstr.get(t1) instanceof String)
				{
					//下载文件
					dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
				}
				
				//如果是文件夹
				if(jstr.get(t1) instanceof JSONObject)
				{
					//创建文件夹
					nfile.mkdirs();
					
					//归递处理
					down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address);
				}
				
			}
		}
		

		

		
	}
	
	@SuppressWarnings("rawtypes")
	private void dele(File folder, JSONObject jstr, ArrayList<File> defile) throws JSONException
	{
		//获取所有的键
		ArrayList<String> keys = new ArrayList<>();
		Iterator iter = jstr.keys();
		while(iter.hasNext())
		{
			keys.add((String)iter.next());
		}
		
		
		
		for(File t1 : folder.listFiles())
		{
			//存在，但是需要进一步判断文件夹里面有没有要删除的东西
			if(keys.contains(t1.getName()))
			{
				//本地是文件夹
				if(t1.isDirectory())
				{
					//远程也是文件夹
					if(jstr.get(t1.getName()) instanceof JSONObject)
					{
						dele(t1, jstr.getJSONObject(t1.getName()), defile);
					}
					
				}
			}
			else//远程也没有这个file，直接删掉
			{
				//记录
				defile.add(t1);
				
				//删除
				del(t1);
			}
		}
		
	}
	
	public void del(File arg)
	{
		if(arg.isDirectory())
		{
			File[] files = arg.listFiles();
			for(File file : files)
			{
				del(file);
			}
		}
		
		arg.delete();
	}
	
	
	
	
}
