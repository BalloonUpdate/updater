package mcbbs.crafttime.tuxingjiemian;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Done extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4433750938506031455L;
	
	public JLabel tip = null;
	
	public Done()
	{
		this.setTitle("");
		this.setSize(200, 70);
		this.setLocationRelativeTo(null);
		this.setUndecorated(true);
		this.setLayout(null);
		
		tip = new JLabel();
		tip.setOpaque(true);
		tip.setBackground(Color.CYAN);
		tip.setBounds(2, 2, 196, 66);
		tip.setHorizontalAlignment(SwingConstants.CENTER);
		tip.setVerticalAlignment(SwingConstants.CENTER);
		tip.setText("完成");
		this.getContentPane().add(tip);
		
	}
	
	public static void main(String[] args) throws InterruptedException 
	{
		Done di = new Done();
		di.setVisible(true);
		
		Thread.sleep(5000);
		di.dispose();

	}

}
