package mcbbs.crafttime.configuration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import mcbbs.crafttime.exception.FileEmpty;

public class Address 
{
	private final String address = "/addresses.txt";
	
	private List<String> addresses = null;
	
	public Address () throws FileEmpty
	{
		try 
		{
			this.addresses = this.loadAddresses();
		} 
		catch (IOException e) {e.printStackTrace();}

	}
	
	private List<String> loadAddresses() throws FileEmpty, IOException
	{
		
		//address.txt
		BufferedReader in = new BufferedReader(new InputStreamReader (this.getClass().getResourceAsStream(address)));
		
		List<String> list = new ArrayList<>();
		
		String temp = "";
		while((temp=in.readLine()) != null)
		{
			list.add(temp);
		}
		
		in.close();
		
		if(list.isEmpty())
		{
			throw new FileEmpty(address);
		}
		
		return list;
		
	}
	
	public List<String> getAddresses()
	{
		return this.addresses;
	}
	
}
