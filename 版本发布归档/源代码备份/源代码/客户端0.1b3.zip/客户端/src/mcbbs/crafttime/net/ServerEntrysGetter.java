package mcbbs.crafttime.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.exception.CannotConnecting;
import mcbbs.crafttime.tuxingjiemian.ConnectingServer;
import mcbbs.crafttime.tuxingjiemian.GettingServerJson;

public class ServerEntrysGetter 
{
	private Address address = null;
	
	public ServerEntrysGetter(Address address)
	{
		//把传来的参数放到成员变量里
		this.address = address;
	}
	
	public ArrayList<Entry> getWorkEntrys() throws CannotConnecting
	{
		Socket s = null;
		ConnectingServer cing = new ConnectingServer();
		cing.setVisible(true);
		try 
		{
			//与服务器建立连接
			s = new Socket(address.getIPaddress(), address.getPort());
			try 
			{
				s.setSoTimeout(5000);
			} catch (SocketException e1) 
			{
				e1.printStackTrace();
			}
			
		} 
		catch (IOException e) 
		{
			//如果无法建立连接
			cing.dispose();
			e.printStackTrace();
			throw new CannotConnecting(address);
		}
		GettingServerJson ging = new GettingServerJson();
		cing.dispose();
		ging.setVisible(true);
		
		//准备io流
		DataInputStream netIn = null;
		DataOutputStream netOut = null;
		
		//用来存储服务端返回的信息
		ArrayList<Entry> wentry = new ArrayList<>();
		
		try 
		{
			//打开io流
			netIn = new DataInputStream(s.getInputStream());
			netOut = new DataOutputStream(s.getOutputStream());
			
			//向服务端说明来意
			netOut.writeInt(0);
			
			String allstr = "";
			
			String tmp = "";
			
			//准备图形界面
			GettingServerJson di = new GettingServerJson();
			//设置为可见
			di.setVisible(true);
			
			//获取服务端发来的信息
			while(!((tmp=netIn.readUTF()).equals("done")))
			{
				allstr += tmp;
			}
			//释放图形界面
			di.dispose();
			
			//关闭套接字
			s.close();
			
			//把返回的字符串转换成JSONArray类型（可能包含多个更新规则）
			JSONArray entryarray = new JSONArray(allstr);
			
			//获取更新规则数量
			int lenth = entryarray.length();
			
			//用来存储所有更新规则
			ArrayList<JSONObject> entrys = new ArrayList<>();
			
			for(int c = 0;c<lenth;c++)
			{
				//把所有更新规则放到集合类里
				entrys.add(entryarray.getJSONObject(c));
			}
			
			
			for(JSONObject temp : entrys)
			{
				System.out.println("服务端返回:"+temp);
				
				//最后的打包工作
				wentry.add(new Entry(address, temp.getString("nick"), new File(temp.getString("path")), temp.getJSONObject("stru")));
			}
			ging.dispose();
		} 
		catch (IOException | JSONException e) {e.printStackTrace();}
		
		//返回
		return wentry;
	}
}
