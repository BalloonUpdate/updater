package mcbbs.crafttime.net;

public class Address 
{
	private String IPaddress = "";
	private int Port = 0;
	
	public Address(String IPaddress, int Port)
	{
		this.IPaddress = IPaddress;
		this.Port = Port;
	}
	
	public String getIPaddress()
	{
		return this.IPaddress;
	}
	
	public int getPort()
	{
		return this.Port;
	}
}
