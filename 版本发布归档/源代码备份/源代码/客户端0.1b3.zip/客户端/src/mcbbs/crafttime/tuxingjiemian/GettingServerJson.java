package mcbbs.crafttime.tuxingjiemian;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

public class GettingServerJson extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2775161304965015178L;
	
	public JProgressBar tip = null;

	public GettingServerJson()
	{
		this.setTitle("");
		this.setSize(170, 22);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setUndecorated(true);
		this.getContentPane().setBackground(new Color(255,69,0));
		tip = new JProgressBar();
		tip.setIndeterminate(true);
		tip.setString("已建立连接，正在获取信息");
		tip.setStringPainted(true);
		tip.setOpaque(true);
		tip.setBackground(Color.GREEN);
		tip.setBounds(2, 2, 166, 18);
		this.getContentPane().add(tip);
	}
	
	
	public static void main (String[] a) throws InterruptedException
	{
		GettingServerJson di = new GettingServerJson();
		di.setVisible(true);
		Thread.sleep(4000);
		di.dispose();
	}
}
