package mcbbs.crafttime.exception;

import mcbbs.crafttime.net.Address;

public class ServerEmpty extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2032816451035204601L;
	
	private Address address = null;
	private String path = null;
	
	public ServerEmpty(Address address,String path)
	{
		this.address = address;
		this.path = path;
	}
	
	public Address getAddress()
	{
		return this.address;
	}
	
	public String getPath()
	{
		return this.path;
	}
}
