package mcbbs.crafttime;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.json.JSONException;
import mcbbs.crafttime.configuration.Address;
import mcbbs.crafttime.configuration.Cmd;
import mcbbs.crafttime.exception.CannotConnecting;
import mcbbs.crafttime.exception.FileEmpty;
import mcbbs.crafttime.net.Entry;
import mcbbs.crafttime.net.ServerEntrysGetter;
import mcbbs.crafttime.tuxingjiemian.Done;
import mcbbs.crafttime.tuxingjiemian.Downloading;
import mcbbs.crafttime.util.EntrysHander;

public class Main 
{

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		Address addconfig = null;
		Cmd cmdconfig = null;
		
		//储存配置文件里所有的地址
		List<String> adds = null;
		
		//储存配置文件里所有的命令
		List<String> cmds = null;
		
		try 
		{
			addconfig = new Address();
		} 
		catch (FileEmpty e) 
		{
			//addresses.txt是空的
			JOptionPane.showMessageDialog(null, e.getMessage(), "", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
		cmdconfig = new Cmd();
		
		//从配置文件里读取所有地址
		adds = addconfig.getAddresses();
		
		//从配置文件里读取所有命令
		cmds = cmdconfig.getCmds();
		
		
		ArrayList<ArrayList<Entry>> E = new ArrayList<>();
		
		//准备工作
		
		//循环获取每一个地址的服务端条目，嵌套储存
		for(String t0 : adds)
		{
			//获取地址和端口
			String[] addressport = t0.split(":");
			
			//获取地址
			String address = addressport[0];
			
			//获取端口
			int port = Integer.parseInt(addressport[1]);
			
			//把地址和端口进行打包，打包成Address类
			mcbbs.crafttime.net.Address add = new mcbbs.crafttime.net.Address(address, port);
			
			//使用服务端条目获取器
			ServerEntrysGetter getes = new ServerEntrysGetter(add);
			
			try 
			{
				//获取并添加到E里面
				E.add(getes.getWorkEntrys());
			}
			catch (CannotConnecting e) 
			{
				//某一个地址无法连接
				JOptionPane.showMessageDialog(null, e.getMessage(), "", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
			
			
		}
		
		////////////////////
		
		
		
		
		//下载
		Downloading ding = new Downloading();
		ding.dq.setIndeterminate(true);
		ding.all.setIndeterminate(true);
		
		ding.setlabeltext("正在计算MD5...");
		
		ding.setVisible(true);
		
		for(ArrayList<Entry> t0 : E)
		{
			try 
			{
				new EntrysHander(t0).h(ding);
			} catch (NoSuchAlgorithmException | JSONException | IOException e) {
				e.printStackTrace();
			};
		}
		
		ding.dispose();
		
		
		//JOptionPane.showMessageDialog(null, "完成", "", JOptionPane.PLAIN_MESSAGE);
		
		Done doe = new Done();
		
		doe.setVisible(true);
		
		Thread.sleep(2000);
		
		doe.dispose();
		
		/*
		new Thread 
		(
			new Runnable()
			{
				public void run()
				{
					
				}
			}
		).start();
		*/
		
		for(String cmd : cmds)
		{
			Runtime.getRuntime().exec(cmd);
		}
		
	}

}
