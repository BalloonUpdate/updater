package mcbbs.crafttime.util;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import mcbbs.crafttime.net.Address;
import mcbbs.crafttime.net.Download;
import mcbbs.crafttime.net.Entry;
import mcbbs.crafttime.tuxingjiemian.Downloading;

public class EntrysHander 
{
	private ArrayList<Entry> hentrys = null;
	
	public EntrysHander(ArrayList<Entry> entrys)
	{
		this.hentrys = entrys;
	}
	
	public void h(Downloading ding) throws JSONException, NoSuchAlgorithmException, IOException
	{
		
		for(Entry t0 : this.hentrys)
		{
			//从条目中获取地址
			Address address = t0.getAddress();
			
			//从条目中获取昵称
			String nick = t0.getNick();
			
			//从条目中获取本地路径
			File folder = t0.getPath();
			
			//从条目中获取JSON
			JSONObject stru = t0.getstru();
			
			//需要下载的文件
			ArrayList<Download> dofile = new ArrayList<>();
			
			//需要删除的文件
			ArrayList<File> defile = new ArrayList<>();
			
			//本地路径(目录)不存在就创建
			if(!folder.exists())
			{
				folder.mkdirs();
			}
			
			//JSON不为空
			if(stru.length()!=0)
			{
				//计算哪些文件要下载
				down(folder, stru, nick+"##", dofile, defile, address, ding);
				
				ding.setlabeltext("服务器:"+address.getIPaddress()+":"+address.getPort());
				
				//计算哪些文件要删除
				dele(folder, stru, defile);
				
				System.out.println("---------------------STA-----"+nick);
				System.out.println("|条目"+address.getIPaddress()+":"+address.getPort()+"本地路径"+folder.getAbsolutePath()+"删除"+defile.size()+"个 | "+"下载X"+dofile.size()+"个");
				
				
				System.out.print("|下载列表:");
				for(Download dw : dofile)
				{
					System.out.print(" ["+dw.getFile().getName()+"] ");
				}
				System.out.println();
				
				
				System.out.print("|删除列表:");
				for(File de : defile)
				{
					System.out.print(" ["+de.getName()+"] ");
				}
				System.out.println();
				
				System.out.println("---------------------END-----"+nick);
				
				//正式开始下载
				
				ding.dq.setIndeterminate(false);
				ding.all.setIndeterminate(false);
				ding.all.setMaximum(dofile.size());
				
				int c = 0;
				
				for(Download dow : dofile)
				{
					c++;
					ding.all.setValue(c);
					dow.dload(ding);
				}
				System.out.println("完成");
			}
			else
			{
				//如果服务端对应文件夹是空的就把本地的也删空
				File[] list = folder.listFiles();
				for(File t : list)
				{
					del(t);
				}
					
			}
			
			
			
			
			
			
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	private void down(File folder, JSONObject jstr, String mypath, ArrayList<Download> dofile, ArrayList<File> defile, Address address, Downloading ding) throws JSONException, NoSuchAlgorithmException, IOException
	{
		//获取所有的键
		//把所有键转换成集合类
		ArrayList<String> keys = new ArrayList<>();
		Iterator iter = jstr.keys();
		while(iter.hasNext())
		{
			keys.add((String)iter.next());
		}
		
		//临时变量
		boolean has = false;
		
		//循环每个键
		for(String t1 : keys)
		{
			//获取路径(目录)下所有的文件
			String[] files = folder.list();
			
			//如果本地文件夹不是空的
			if(files.length!=0)
			{
				
				//把每一个键在本地进行搜索
				for(String t2 : files)
				{
					if(t1.equals(t2))
					{
						//如果搜索到了就记录下来
						has = true;
					}
				}
				
				//建立对应File的实例
				File nfile = new File(folder, t1);
				
				//如果搜得到结果
				if(has)
				{
					
					//远程端是文件
					if(jstr.get(t1) instanceof String)
					{
						//本地是文件
						if(nfile.isFile())
						{
							//验证md5
							ding.dq.setString(nfile.getName());
							String no = MD5.getMD5(nfile).toUpperCase();
							String ol = jstr.getString(t1);
							if(!no.equals(ol))
							{
								//放入下载列表
								dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
								
							}
						}
						
						//本地是文件夹
						if(nfile.isDirectory())
						{
							//记录被删除的文件
							defile.add(nfile);
							//删除掉
							del(nfile);
							
							//放入下载列表
							dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
						}
					}
					
					//远程端是文件夹
					if(jstr.get(t1) instanceof JSONObject)
					{
						//本地是文件
						if(nfile.isFile())
						{
							//记录被删除的文件
							defile.add(nfile);
							
							//删掉
							del(nfile);
							
							//创建文件夹
							nfile.mkdirs();
							
							//归递处理
							down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address, ding);
						}
						
						//本地是文件夹
						if(nfile.isDirectory())
						{
							//归递处理
							down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address, ding);
						}
						
					}
					
				}
				else//如果没有搜到结果
				{
					//远程端是文件
					if(jstr.get(t1) instanceof String)
					{
						//放入下载列表
						dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
					}
					
					//远程端是文件夹
					if(jstr.get(t1) instanceof JSONObject)
					{
						//创建文件夹
						nfile.mkdirs();
						
						//归递处理
						down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address, ding);
					}
					
				}
				//清零
				has = false;
			}
			else//如果本地文件夹是空的
			{
				//建立对应File的实例
				File nfile = new File(folder, t1);
				
				//如果是文件
				if(jstr.get(t1) instanceof String)
				{
					//放入下载列表
					dofile.add(new Download(mypath+"####"+nfile.getName(), nfile, address));
				}
				
				//如果是文件夹
				if(jstr.get(t1) instanceof JSONObject)
				{
					//创建文件夹
					nfile.mkdirs();
					
					//归递处理
					down(nfile, jstr.getJSONObject(t1), mypath+"####"+t1, dofile, defile, address, ding);
				}
				
			}
		}
		

		

		
	}
	
	@SuppressWarnings("rawtypes")
	private void dele(File folder, JSONObject jstr, ArrayList<File> defile) throws JSONException
	{
		//获取所有的键
		ArrayList<String> keys = new ArrayList<>();
		Iterator iter = jstr.keys();
		while(iter.hasNext())
		{
			keys.add((String)iter.next());
		}
		
		
		
		for(File t1 : folder.listFiles())
		{
			//存在，但是需要进一步判断文件夹里面有没有要删除的东西
			if(keys.contains(t1.getName()))
			{
				//本地是文件夹
				if(t1.isDirectory())
				{
					//远程也是文件夹
					if(jstr.get(t1.getName()) instanceof JSONObject)
					{
						dele(t1, jstr.getJSONObject(t1.getName()), defile);
					}
					
				}
			}
			else//远程也没有这个file，直接删掉
			{
				//记录
				defile.add(t1);
				
				//删除
				del(t1);
			}
		}
		
	}
	
	public void del(File arg)
	{
		if(arg.isDirectory())
		{
			File[] files = arg.listFiles();
			for(File file : files)
			{
				del(file);
			}
		}
		
		arg.delete();
	}
	
	
	
	
}
