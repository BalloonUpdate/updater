package mcbbs.crafttime.tuxingjiemian;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

public class ConnectingServer extends JFrame 
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9110625038855388485L;
	public JProgressBar tip = null;
	
	
	public ConnectingServer()
	{
		this.setTitle("");
		this.setSize(96, 22);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setUndecorated(true);
		this.getContentPane().setBackground(new Color(255,69,0));
		tip = new JProgressBar();
		tip.setIndeterminate(true);
		tip.setString("正在连接服务器");
		tip.setStringPainted(true);
		tip.setOpaque(true);
		tip.setBackground(Color.BLUE);
		tip.setBounds(2, 2, 92, 18);
		this.getContentPane().add(tip);
	}
	
	
	
	public static void main (String[] a) throws InterruptedException
	{
		
		ConnectingServer di = new ConnectingServer();
		di.setVisible(true);
		Thread.sleep(4000);
		di.dispose();
		
	}
	
}
