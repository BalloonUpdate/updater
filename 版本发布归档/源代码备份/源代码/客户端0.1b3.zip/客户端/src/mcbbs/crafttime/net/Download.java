package mcbbs.crafttime.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import mcbbs.crafttime.tuxingjiemian.Downloading;

public class Download 
{
	private String myPath = null;
	private File file = null;
	private Address address = null;
	
	public Download(String myPath, File file, Address address)
	{
		this.myPath = myPath;
		this.file = file;
		this.address = address;
	}
	
	public void dload(Downloading d) throws UnknownHostException, IOException
	{
		if(!file.exists())
		{
			file.createNewFile();
		}
		
		FileOutputStream fileOut = new FileOutputStream(file);
		
		Socket s = new Socket(address.getIPaddress(), address.getPort());
		
		DataOutputStream netOut = new DataOutputStream(s.getOutputStream());
		DataInputStream netIn = new DataInputStream(s.getInputStream());
		
		netOut.writeInt(1);
		
		netOut.writeUTF(myPath);
		
		long size = netIn.readLong();
		
		byte[] buffer = new byte[1024*8];
		
		int len = 0;
		
		d.dq.setString(file.getName());
		
		while((len = netIn.read(buffer))!=-1)
		{
			fileOut.write(buffer, 0, len);
			
			d.dq.setValue((int)(((double)file.length()/(double)size)*100));
			
			//System.out.println((new DecimalFormat("#.00").format((((double)file.length()/(double)size)*100)))+" %");
			
		}
		
		fileOut.close();
		s.close();
		
		
	}
	
	public File getFile()
	{
		return this.file;
	}
}
