package mcbbs.crafttime.tuxingjiemian;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;

public class Downloading extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2775161304965015178L;
	
	public JProgressBar dq = null;
	public JProgressBar all = null;
	public JLabel address = null;
	
	public Downloading()
	{
		this.setTitle("");
		this.setSize(200, 70);
		this.setLocationRelativeTo(null);
		this.setUndecorated(true);
		this.setLayout(null);
		
		dq = new JProgressBar();
		all = new JProgressBar();
		address = new JLabel();
		
		dq.setOpaque(true);
		all.setOpaque(true);
		address.setOpaque(true);
		
		
		dq.setBackground(Color.GREEN);
		all.setBackground(Color.BLUE);
		address.setBackground(Color.YELLOW);
		
		dq.setBounds(2, 2, 196, 20);
		all.setBounds(2, 24, 196, 20);
		address.setBounds(2, 48, 196, 20);
		
		
		dq.setStringPainted(true);
		all.setStringPainted(true);
		address.setHorizontalAlignment(SwingConstants.CENTER);
		
		dq.setString("");
		address.setText("");
		
		dq.setValue(50);
		
		
		this.getContentPane().add(dq);
		this.getContentPane().add(all);
		this.getContentPane().add(address);
	}
	
	public void setFileName(String name)
	{
		dq.setString(name);
	}
	
	public void setdq(int a)
	{
		dq.setValue(a);
	}
	
	public void setall(int a)
	{
		all.setValue(a);
	}
	
	public void setlabeltext(String a)
	{
		address.setText(a);
	}
	
	
	public static void main (String[] a) throws InterruptedException
	{
		Downloading di = new Downloading();
		di.setVisible(true);
		
		
		
		Thread.sleep(5000);
		di.dispose();
	}
	
	
}
