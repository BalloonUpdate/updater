package mcbbs.crafttime.configuration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Cmd 
{
	private final String cmd = "/cmds.txt";
	
	private List<String> cmds = null;
	
	public Cmd()
	{
		try 
		{
			this.cmds = this.loadcmds();
		} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	private List<String> loadcmds() throws IOException
	{
		//cmds.txt
		BufferedReader in = new BufferedReader(new InputStreamReader (this.getClass().getResourceAsStream(cmd)));
		
		List<String> list = new ArrayList<>();
		
		String temp = "";
		while((temp=in.readLine()) != null)
		{
			if(temp!="")
			{
				list.add(temp);
			}
		}
		
		in.close();
		
		return list;
		
	}
	
	public List<String> getCmds()
	{
		return this.cmds;
	}
	
}
